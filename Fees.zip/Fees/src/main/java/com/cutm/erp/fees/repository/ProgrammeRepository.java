package com.cutm.erp.fees.repository;

import com.cutm.erp.fees.entity.Programme;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProgrammeRepository extends JpaRepository<Programme,Integer> {
}
