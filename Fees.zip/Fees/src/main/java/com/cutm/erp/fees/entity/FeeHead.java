package com.cutm.erp.fees.entity;

public enum FeeHead {
    UNDEFINED,
    ACADEMIC,
    HOSTEL,
    TRANSPORT,
    MISCELLANEOUS
}
