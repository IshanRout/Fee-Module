package com.cutm.erp.fees.repository;

import com.cutm.erp.fees.entity.HostelFeeMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HostelFeeMasterRepository extends JpaRepository<HostelFeeMaster,Integer> {

}
