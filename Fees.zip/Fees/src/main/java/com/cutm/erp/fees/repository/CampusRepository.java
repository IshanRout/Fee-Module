package com.cutm.erp.fees.repository;

import com.cutm.erp.fees.entity.Campus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CampusRepository extends JpaRepository<Campus,Integer> {
}
