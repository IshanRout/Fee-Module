package com.cutm.erp.fees.repository;

import com.cutm.erp.fees.entity.TransportationMaster;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransportationMasterRepository extends JpaRepository<TransportationMaster,Integer> {
}
