package com.cutm.erp.fees.entity;

public enum RoomCategory {
    UNDEFINED,
    REGULAR_ROOMS,
    NON_AC_AND_DELUXE_ROOMS,
    AC_AND_DELUXE_ROOMS;
}