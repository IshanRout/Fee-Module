package com.cutm.erp.fees.repository;

import com.cutm.erp.fees.entity.MiscellaneousHead;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MiscellaneousHeadRepository extends JpaRepository<MiscellaneousHead,Integer> {

}
