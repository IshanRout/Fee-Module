package com.cutm.erp.fees.entity;

public enum StudentType {
    UNDEFINED,
    REGULAR,
    LATERAL_ENTRY;
}
