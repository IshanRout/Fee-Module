package com.cutm.erp.fees.entity;

public enum Role {
    UNDEFINED,
    STUDENT,
    FACULTY,
    ADMIN;
}
